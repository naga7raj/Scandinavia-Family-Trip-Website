# Scandinavia Family Trip Website

Responsive public travel dashboard for a July 2026 family trip covering Bergen, Oslo and Copenhagen.

## Included
- Day-by-day itinerary
- Booking progress tracker
- Packing checklist saved in the browser
- Currency planning
- Google Maps links
- Mobile design, countdown and dark mode

## Publish with GitHub Pages
1. Upload all files to the repository root.
2. Open **Settings → Pages**.
3. Choose **Deploy from a branch**.
4. Select **main** and **/(root)**.
5. Click **Save**.

This public version excludes booking references, security codes, payment details, personal documents and exact accommodation addresses.
