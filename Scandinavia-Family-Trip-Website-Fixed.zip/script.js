const tripStart=new Date('2026-07-21T08:00:00+02:00');
const itinerary=[
{date:'21 July',city:'Amsterdam → Bergen',items:['Travel to Bergen and settle in','12:30–15:00 · VilVite','15:30–17:30 · Bryggen','17:40–19:10 · Bergenhus Fortress','19:10–20:15 · Vågen']},
{date:'22 July',city:'Bergen',items:['10:00–13:30 · Mostraumen Fjord Cruise','14:00–18:00 · Fløibanen and Mount Fløyen','Playground and Troll Forest','Fish Market · optional']},
{date:'23 July',city:'Bergen → Oslo',items:['08:08–15:09 · Vy train','16:15–17:15 · Oslo Opera House','17:15–19:30 · MUNCH Museum']},
{date:'24 July',city:'Oslo → Copenhagen',items:['08:30–10:30 · Vigeland Sculpture Park','14:30 · Arrive at cruise terminal','16:30 · Overnight cruise departure']},
{date:'25 July',city:'Copenhagen',items:['11:30 · Nyhavn','13:30 · Canal Cruise','15:00 · Amalienborg','Little Mermaid · optional']},
{date:'26 July',city:'Copenhagen',items:['13:00–22:00 · Tivoli Gardens','Dinner inside Tivoli']},
{date:'27 July',city:'Copenhagen → Amsterdam',items:['09:30–13:30 · Experimentarium','16:15 · Target airport arrival','19:10 · KLM flight']}
];
const bookings=[
{name:'Flights',details:'Outbound and return flights',status:'Paid'},
{name:'Accommodation',details:'Bergen, Oslo and Copenhagen',status:'Paid'},
{name:'Bergen–Oslo train',details:'23 July · 08:08–15:09',status:'Paid'},
{name:'Oslo–Copenhagen cruise',details:'24 July · 16:30',status:'Paid'},
{name:'Mostraumen cruise',details:'22 July · 10:00',status:'Pending'},
{name:'MUNCH Museum',details:'Book closer to the visit',status:'Pending'},
{name:'Canal Cruise',details:'Book 1–2 days before',status:'Pending'},
{name:'Tivoli Gardens',details:'Book 1–2 days before',status:'Pending'},
{name:'Experimentarium',details:'Buy on the day',status:'Pending'}
];
const packing=['Passports and residence documents','Travel insurance details','Phone chargers','Power bank','Waterproof jackets','Compact umbrellas','Water-resistant shoes','Layered clothing','Medicines','Child snacks','Reusable water bottles','Offline Google Maps','Skyss, Vy and Ruter apps','Rejsebillet and Rejseplanen apps','Tickets available in email or apps'];

function updateCountdown(){
 const diff=tripStart-new Date(), el=document.getElementById('countdown');
 if(diff<=0){el.textContent='The journey has begun';return;}
 const days=Math.floor(diff/86400000),hours=Math.floor((diff%86400000)/3600000),minutes=Math.floor((diff%3600000)/60000);
 el.textContent=`${days} days · ${hours} hours · ${minutes} minutes`;
}
document.getElementById('itineraryList').innerHTML=itinerary.map(day=>`<article class="timeline-card"><div class="timeline-date">${day.date}</div><div class="timeline-content"><h3>${day.city}</h3><ul>${day.items.map(item=>`<li>${item}</li>`).join('')}</ul></div></article>`).join('');
document.getElementById('bookingList').innerHTML=bookings.map(item=>`<article class="booking-card"><h3>${item.name}</h3><p>${item.details}</p><span class="status ${item.status==='Paid'?'paid':'pending'}">${item.status}</span></article>`).join('');

function renderPacking(){
 const saved=JSON.parse(localStorage.getItem('scandiPacking')||'{}');
 const list=document.getElementById('packingList');
 list.innerHTML=packing.map((item,index)=>`<label class="check-item ${saved[index]?'done':''}"><input type="checkbox" data-index="${index}" ${saved[index]?'checked':''}><span>${item}</span></label>`).join('');
 list.querySelectorAll('input').forEach(box=>box.addEventListener('change',e=>{
   const latest=JSON.parse(localStorage.getItem('scandiPacking')||'{}');
   latest[e.target.dataset.index]=e.target.checked;
   localStorage.setItem('scandiPacking',JSON.stringify(latest));
   e.target.closest('.check-item').classList.toggle('done',e.target.checked);
 }));
}
document.getElementById('resetPacking').addEventListener('click',()=>{localStorage.removeItem('scandiPacking');renderPacking();});
renderPacking();updateCountdown();setInterval(updateCountdown,60000);